# 💇‍♂️Grooming Reservation System Project💅
Building on the idea of a salon services web application that allows users to book appointments at salons or opt for home services.
