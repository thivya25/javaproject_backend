package com.edu.grooming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroomingReservationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroomingReservationSystemApplication.class, args);

	}

}



	







	





