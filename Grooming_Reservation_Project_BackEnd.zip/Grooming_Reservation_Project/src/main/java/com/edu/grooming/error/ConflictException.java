package com.edu.grooming.error;

public class ConflictException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ConflictException(String s) {
		super(s);
	}


}
